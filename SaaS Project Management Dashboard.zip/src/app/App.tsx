import { ModernHeader } from './components/ModernHeader';
import { ModernSidebar } from './components/ModernSidebar';
import { ModernKanbanBoard } from './components/ModernKanbanBoard';

export default function App() {
  return (
    <div className="flex h-screen flex-col bg-gradient-to-br from-gray-50 to-gray-100/50">
      <ModernHeader />
      
      <div className="flex flex-1 overflow-hidden">
        <ModernSidebar />
        
        <main className="flex-1 overflow-y-auto">
          <div className="p-8">
            {/* Page Header */}
            <div className="mb-8">
              <div className="mb-2 flex items-center gap-2">
                <span className="text-sm text-gray-500">Projects</span>
                <span className="text-gray-300">/</span>
                <span className="text-sm font-medium text-gray-900">Website Redesign</span>
              </div>
              <h1 className="mb-2 text-3xl font-bold text-gray-900">Sprint Board</h1>
              <p className="text-gray-600">
                Track and manage all development tasks for the current sprint
              </p>
            </div>

            {/* Kanban Board - 4 Distinct Columns */}
            <ModernKanbanBoard />
          </div>
        </main>
      </div>
    </div>
  );
}