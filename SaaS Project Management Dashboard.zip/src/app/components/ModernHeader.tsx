import { Search, Bell, ChevronDown, Plus } from 'lucide-react';

export function ModernHeader() {
  return (
    <header className="bg-white/80 backdrop-blur-lg">
      <div className="flex items-center justify-between px-8 py-4">
        {/* Left side - Logo and Search */}
        <div className="flex items-center gap-8 flex-1">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 shadow-lg shadow-violet-500/30">
              <span className="font-bold text-white text-sm">PM</span>
            </div>
            <span className="font-semibold text-gray-900 text-lg">ProjectFlow</span>
          </div>
          
          <div className="relative max-w-md flex-1">
            <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search projects, tasks, or team members..."
              className="w-full rounded-xl bg-gray-50/80 py-2.5 pl-11 pr-4 text-sm outline-none transition-all placeholder:text-gray-400 focus:bg-white focus:shadow-lg focus:shadow-gray-200/50 focus:ring-2 focus:ring-violet-500/20"
            />
          </div>
        </div>

        {/* Right side - Actions and Profile */}
        <div className="flex items-center gap-4">
          <button className="flex items-center gap-2 rounded-xl bg-violet-600 px-4 py-2.5 text-sm font-medium text-white shadow-lg shadow-violet-500/30 transition-all hover:bg-violet-700 hover:shadow-xl hover:shadow-violet-500/40">
            <Plus className="h-4 w-4" />
            New Task
          </button>

          <div className="h-8 w-px bg-gray-200"></div>

          <button className="relative rounded-xl p-2.5 transition-all hover:bg-gray-100">
            <Bell className="h-5 w-5 text-gray-600" />
            <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-rose-500 ring-2 ring-white"></span>
          </button>

          <div className="flex items-center gap-3 rounded-xl bg-gray-50 py-1.5 pl-1.5 pr-3 transition-all hover:bg-gray-100 cursor-pointer">
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-violet-500 to-purple-600 shadow-md"></div>
            <div className="flex flex-col">
              <span className="text-sm font-medium text-gray-900">Alex Morgan</span>
              <span className="text-xs text-gray-500">Product Team</span>
            </div>
            <ChevronDown className="h-4 w-4 text-gray-400" />
          </div>
        </div>
      </div>
    </header>
  );
}
