
  # SaaS Project Management Dashboard

  This is a code bundle for SaaS Project Management Dashboard. The original project is available at https://www.figma.com/design/wIcIlQgo8i0YlmgfbvEVwo/SaaS-Project-Management-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  