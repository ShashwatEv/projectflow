import { LayoutGrid, Inbox, Users, Calendar, Settings, TrendingUp, Zap } from 'lucide-react';

const navigation = [
  { name: 'Overview', icon: LayoutGrid, active: false, badge: null },
  { name: 'My Tasks', icon: Inbox, active: false, badge: '12' },
  { name: 'Projects', icon: Zap, active: true, badge: null },
  { name: 'Team', icon: Users, active: false, badge: null },
  { name: 'Calendar', icon: Calendar, active: false, badge: null },
  { name: 'Analytics', icon: TrendingUp, active: false, badge: null },
];

const projects = [
  { name: 'Website Redesign', color: 'bg-blue-500', progress: 75 },
  { name: 'Mobile App V2', color: 'bg-emerald-500', progress: 45 },
  { name: 'API Integration', color: 'bg-amber-500', progress: 90 },
  { name: 'Marketing Campaign', color: 'bg-rose-500', progress: 30 },
];

export function ModernSidebar() {
  return (
    <aside className="w-72 bg-white">
      <div className="flex h-full flex-col p-6">
        {/* Navigation */}
        <nav className="space-y-1">
          {navigation.map((item) => (
            <button
              key={item.name}
              className={`flex w-full items-center justify-between rounded-xl px-4 py-3 text-sm font-medium transition-all ${
                item.active
                  ? 'bg-gradient-to-r from-violet-500 to-purple-600 text-white shadow-lg shadow-violet-500/30'
                  : 'text-gray-700 hover:bg-gray-50'
              }`}
            >
              <div className="flex items-center gap-3">
                <item.icon className="h-5 w-5" />
                <span>{item.name}</span>
              </div>
              {item.badge && (
                <span className={`rounded-lg px-2 py-0.5 text-xs font-semibold ${
                  item.active ? 'bg-white/20 text-white' : 'bg-gray-100 text-gray-700'
                }`}>
                  {item.badge}
                </span>
              )}
            </button>
          ))}
        </nav>

        {/* Projects Section */}
        <div className="mt-8 flex-1">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-gray-500">
              Active Projects
            </h3>
          </div>
          <div className="space-y-3">
            {projects.map((project) => (
              <div
                key={project.name}
                className="group cursor-pointer rounded-xl p-3 transition-all hover:bg-gray-50"
              >
                <div className="mb-2 flex items-center gap-3">
                  <div className={`h-2 w-2 rounded-full ${project.color}`}></div>
                  <span className="text-sm font-medium text-gray-900">{project.name}</span>
                </div>
                <div className="ml-5">
                  <div className="h-1.5 overflow-hidden rounded-full bg-gray-100">
                    <div
                      className={`h-full rounded-full ${project.color}`}
                      style={{ width: `${project.progress}%` }}
                    ></div>
                  </div>
                  <span className="mt-1 text-xs text-gray-500">{project.progress}% Complete</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Settings at bottom */}
        <button className="flex w-full items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium text-gray-700 transition-all hover:bg-gray-50">
          <Settings className="h-5 w-5" />
          <span>Settings</span>
        </button>
      </div>
    </aside>
  );
}
